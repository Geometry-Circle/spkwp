<?php include_once('../_header.php'); ?>

<section class="content">
  <main>
    <div class="row">
      <div class="col-lg-12">
        <h2 class="text-center">Selamat Datang di <br> Aplikasi Sistem Pendukung Keputusan Beasiswa Berprestasi </h2>
        <h1 class="text-center fw-bolder"> SD Negeri 1 Salakan Potorono Yogyakarta</h1>
      </div>
    </div>
  </main>
</section>
<?php include_once('../_footer.php'); ?>